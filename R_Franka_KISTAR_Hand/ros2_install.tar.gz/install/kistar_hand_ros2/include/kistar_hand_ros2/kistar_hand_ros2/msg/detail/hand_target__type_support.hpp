// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from kistar_hand_ros2:msg/HandTarget.idl
// generated code does not contain a copyright notice

#ifndef KISTAR_HAND_ROS2__MSG__DETAIL__HAND_TARGET__TYPE_SUPPORT_HPP_
#define KISTAR_HAND_ROS2__MSG__DETAIL__HAND_TARGET__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "kistar_hand_ros2/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_kistar_hand_ros2
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  kistar_hand_ros2,
  msg,
  HandTarget
)();
#ifdef __cplusplus
}
#endif

#endif  // KISTAR_HAND_ROS2__MSG__DETAIL__HAND_TARGET__TYPE_SUPPORT_HPP_
