// generated from rosidl_generator_c/resource/idl.h.em
// with input from kistar_hand_ros2:msg/FrankaArmState.idl
// generated code does not contain a copyright notice

#ifndef KISTAR_HAND_ROS2__MSG__FRANKA_ARM_STATE_H_
#define KISTAR_HAND_ROS2__MSG__FRANKA_ARM_STATE_H_

#include "kistar_hand_ros2/msg/detail/franka_arm_state__struct.h"
#include "kistar_hand_ros2/msg/detail/franka_arm_state__functions.h"
#include "kistar_hand_ros2/msg/detail/franka_arm_state__type_support.h"

#endif  // KISTAR_HAND_ROS2__MSG__FRANKA_ARM_STATE_H_
