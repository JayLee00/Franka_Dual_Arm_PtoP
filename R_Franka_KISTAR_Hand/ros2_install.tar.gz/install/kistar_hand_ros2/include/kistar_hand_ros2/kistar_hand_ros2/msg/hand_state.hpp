// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef KISTAR_HAND_ROS2__MSG__HAND_STATE_HPP_
#define KISTAR_HAND_ROS2__MSG__HAND_STATE_HPP_

#include "kistar_hand_ros2/msg/detail/hand_state__struct.hpp"
#include "kistar_hand_ros2/msg/detail/hand_state__builder.hpp"
#include "kistar_hand_ros2/msg/detail/hand_state__traits.hpp"
#include "kistar_hand_ros2/msg/detail/hand_state__type_support.hpp"

#endif  // KISTAR_HAND_ROS2__MSG__HAND_STATE_HPP_
