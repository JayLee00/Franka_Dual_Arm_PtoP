// generated from rosidl_generator_c/resource/idl.h.em
// with input from kistar_hand_ros2:msg/HandTarget.idl
// generated code does not contain a copyright notice

#ifndef KISTAR_HAND_ROS2__MSG__HAND_TARGET_H_
#define KISTAR_HAND_ROS2__MSG__HAND_TARGET_H_

#include "kistar_hand_ros2/msg/detail/hand_target__struct.h"
#include "kistar_hand_ros2/msg/detail/hand_target__functions.h"
#include "kistar_hand_ros2/msg/detail/hand_target__type_support.h"

#endif  // KISTAR_HAND_ROS2__MSG__HAND_TARGET_H_
